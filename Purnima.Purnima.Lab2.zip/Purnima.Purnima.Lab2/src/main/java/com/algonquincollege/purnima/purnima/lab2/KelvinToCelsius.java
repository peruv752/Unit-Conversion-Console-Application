/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting Kelvin to Celcius  .
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from   Kelvin(K) to Celsius(C) using the formula.
 * </p>
 * <pre>
 *   celsius = kelvin - 273.15
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Kelvin
 * and three decimal places for Celsius.
 * </p>
 * @author Purnima
 * 
 */
public class KelvinToCelsius implements IConversionStrategy  {
       /**
    * converts the given temperature in  Kelvin to Celsius  and prints the result.
    * @param kelvin  the temperature value in kelvin.
    */ 
    @Override
    public void convert(double kelvin) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double celsius = kelvin - 273.15;
       System.out.printf("From %.2f K to %.3f Degree C%n",kelvin, celsius);
    }
}
