
package com.algonquincollege.purnima.purnima.lab2;

/**
 *Strategy interface for unit conversion operations.
 * <p>
 * This interface defines the contract that all concrete conversions strategies
 * (eg., Celsius to Fahrenheit, Meter to Kilometer) must implement.
 * It allows the {@code UnitContext} class to use any of these strategies
 * interchangeability at runtime.
 * </p>
 * 
 * <p>
 * Implementing classes must define the logic for converting a numeric input and
 * printing or returning the result as needed.
 * @author DELL
 */
public interface IConversionStrategy {
    /**
     * Performs a unit conversion operation based on the specific implementation.
     * @param input  the numeric input value to convert.
     */
    void convert(double input);
}
