/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting  meters to Kilometers   .
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from  Meters to Kilometers using the formula.
 * </p>
 * <pre>
 *kilometer = meter/1000
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for meters
 * and three decimal places for Kilometers.
 * </p>
 * @author Purnima
 * 
 */
public class MeterToKilometer implements IConversionStrategy  {
      /**
    * converts the given distance in   Meters  to kilometers and prints the result.
    * @param meter  the distance value in meters.
    */ 
    @Override
    public void convert(double meter) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double kilometer = meter/1000;
       System.out.printf("From %.2f m to %.3f km%n",meter, kilometer);
    }
}
