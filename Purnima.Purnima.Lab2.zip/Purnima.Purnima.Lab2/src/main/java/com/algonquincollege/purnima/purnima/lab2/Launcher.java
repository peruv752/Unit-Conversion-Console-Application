
package com.algonquincollege.purnima.purnima.lab2;


/**
 * Launcher class to demonstrate temperature  and distance unit conversions
 * using the Strategy Design Pattern.
 * <p>
 * This class creates a UnitContext object and switches between different
 * conversion strategies to perform conversions on the same input value.
 * <p>
 * @author Purnima
 * 
 */
public class Launcher {
    /**
     * Main method to run the conversion demonstration.
     * It sets different conversion strategies on the UnitContext  and
     * converts the same numeric input using each strategy.
     * 
     * @param args Command line arguments(not used)
     */
    public static void main(String[] args){
        //Create the context that will use different conversion strategies
        UnitContext context = new UnitContext();
        
        //Convert Celsius to Fahrenheit
        context.setConversionStrategy(new CelsiusToFahrenheit());
        context.convert(19.32);
        
        //Convert Celsius to Kelvin
        context.setConversionStrategy(new CelsiusToKelvin());
        context.convert(19.32);
     
        //Convert Fahrenheit to Celsius
        context.setConversionStrategy(new FahrenheitToCelsius());
        context.convert(19.32);
        
        //Convert Fahrenheit to Kelvin
        context.setConversionStrategy(new FahrenheitToKelvin());
        context.convert(19.32); 
        
        //Convert Kelvin to Fahrenheit
        context.setConversionStrategy(new KelvinToFahrenheit());
        context.convert(19.32);
        
        //Convert Kelvin to Celsius
        context.setConversionStrategy(new KelvinToCelsius());
        context.convert(19.32); 
        //Convert Kilometer to Meter        
        context.setConversionStrategy(new KilometerToMeter());
        context.convert(19.32); 
        
        ////Convert Meter to Kilometer
        context.setConversionStrategy(new MeterToKilometer());
        context.convert(19.32); 
              
         //Program aurthor Information      
        System.out.println("----------------------------------------------------------------------------------------------");
        System.out.println("Program by: Purnima Purnima (041161250)");
        System.out.println("For: 25S CST8288 Section 012 Lab Problem 2");
        System.out.println();
}}
