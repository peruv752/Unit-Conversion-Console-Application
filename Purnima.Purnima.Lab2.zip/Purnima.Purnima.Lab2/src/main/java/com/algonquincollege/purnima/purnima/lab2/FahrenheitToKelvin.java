
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting Fahrenheit to Kelvin .
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from  Fahrenheit(F) to Kelvin(K) using the formula.
 * </p>
 * <pre>
 *   kelvin = (fahrenheit + 459.67)* 5/9
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Fahrenheit
 * and three decimal places for Kelvin.
 * </p>
 * @author Purnima
 * 
 */
public class FahrenheitToKelvin implements IConversionStrategy  {
       /**
    * converts the given temperature in Fahrenheit to Kelvin  and prints the result.
    * @param fahrenheit  the temperature value in Fahrenheit.
    */  
    @Override
    public void convert(double fahrenheit) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double kelvin = (fahrenheit + 459.67)* 5/9;
       System.out.printf("From %.2f F to %.3f K %n",fahrenheit,kelvin);
    }
}

