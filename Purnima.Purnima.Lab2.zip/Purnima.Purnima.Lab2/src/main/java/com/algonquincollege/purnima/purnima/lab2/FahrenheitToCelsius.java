
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting Fahrenheit to Celsius .
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from  Fahrenheit(F) to Celsius(C) using the formula.
 * </p>
 * <pre>
 *  Celsius = (fahrenheit-32)* 5/9
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Fahrenheit
 * and three decimal places for Celsius.
 * </p>
 * @author Purnima
 * 
 */
public class FahrenheitToCelsius implements IConversionStrategy {
     /**
    * converts the given temperature in Fahrenheit to Celsius  and prints the result.
    * @param fahrenheit  the temperature value in Fahrenheit.
    */ 
    @Override
    public void convert(double fahrenheit) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double celsius = (fahrenheit-32)* 5/9;
       System.out.printf("From %.2f F to %.3f Degree C%n",fahrenheit,celsius);
    }
}
