
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting Celsius to Kelvin.
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from degree Celcius(C) to Kelvin (K) using the formula.
 * </p>
 * <pre>
 * Kelvin = Celsius + 273.15
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Celsius 
 * and three decimal places for Kelvin.
 * </p>
 * @author Purnima
 * 
 */
public class CelsiusToKelvin implements IConversionStrategy {
      /**
    * converts the given temperature in Celsius to Kelvin and prints the result.
    * @param celsius the temperature value in degrees Celsius.
    */
    @Override
    public void convert(double celsius) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double kelvin = celsius + 273.15;
       System.out.printf("From %.2f Degree C to %.3f K %n",celsius,kelvin);
    }
    
}
