
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting Celsius to Fahrenheit.
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from degree Celcius(C) to Fahrenheit (F) using the formula.
 * </p>
 * <pre>
 * Fahrenheit = (Celsius *9/5) +32
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Celsius 
 * and three decimal places for Fahrenheit.
 * </p>
 * @author Purnima
 * 
 */
public class CelsiusToFahrenheit implements IConversionStrategy {

   /**
    * converts the given temperature in Celsius to Fahrenheit and prints the result.
    * @param celsius the temperature value in degrees Celsius.
    */
    @Override
    public void convert(double celsius){
    double fahrenheit = (celsius * 9/5) +32;
   System.out.printf("From %.2f Degree C to %.3f F %n",celsius,fahrenheit);
    }
}
