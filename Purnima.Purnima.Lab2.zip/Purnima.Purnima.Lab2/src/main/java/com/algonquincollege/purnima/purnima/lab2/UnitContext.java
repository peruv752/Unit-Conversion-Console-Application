
package com.algonquincollege.purnima.purnima.lab2;


;

/**
 * <p>
 * Initially, it defaults to {@code CelsiusToFahrenheit} conversion strategy,
 * but can be changed via the {@code setConversionStrategy()}method.
 * </p>
 * 
 * @author Purnima
 * @version 1.0
 */
public class UnitContext {
    /*Holds the ConversionStrategy */
  private IConversionStrategy conversion;  
 
  /**
   * Default Constructor.
   * Initializes with {@code CelsiusToFahrenheit} as a default strategy.
   */
  public UnitContext(){
      this.conversion = new CelsiusToFahrenheit();
  }
  /**
   * Parameterized constructor to set a specific conversion strategy
   * @param conversion  the initial conversion strategy to use.
   */
   public UnitContext(IConversionStrategy conversion){
      this.conversion = conversion;
      
  }
   /**
    * Sets a new conversion strategy at runtime.
    * 
    * @param conversion the conversion strategy to set.
    */
   public void setConversionStrategy(IConversionStrategy conversion){
          this.conversion = conversion;
          
}
/**
 * Executes the currently set conversion strategy on the provided value.
 * @param value the numeric value to convert.
 */
      public void convert(double value){
          if(conversion != null){
          conversion.convert( value);
                  }
          else{
              System.out.println("No Conversion Strategy Set.");
          }
      }
      }