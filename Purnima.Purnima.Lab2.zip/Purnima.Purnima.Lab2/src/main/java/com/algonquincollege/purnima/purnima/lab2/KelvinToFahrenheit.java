/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.algonquincollege.purnima.purnima.lab2;


/**
 * Concrete strategy for converting Kelvin to Fahrenheit  .
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from   Kelvin(K) to Fahrenheit(F) using the formula.
 * </p>
 * <pre>
 *  fahrenheit = (kelvin * 9/5) - 459.67
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Kelvin
 * and three decimal places for Fahrenheit.
 * </p>
 * @author Purnima
 * 
 */
public class KelvinToFahrenheit implements IConversionStrategy  {
       /**
    * converts the given temperature in  Kelvin to Fahrenheit and prints the result.
    * @param kelvin  the temperature value in kelvin.
    */ 
    @Override
    public void convert(double kelvin) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double fahrenheit = (kelvin * 9/5) - 459.67;
       System.out.printf("From %.2f K to %.3f F%n",kelvin, fahrenheit);
    }
}
