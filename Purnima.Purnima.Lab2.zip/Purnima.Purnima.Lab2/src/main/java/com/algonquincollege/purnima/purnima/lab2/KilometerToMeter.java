/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.algonquincollege.purnima.purnima.lab2;

/**
 * Concrete strategy for converting Kilometers to meters  .
 * <p>
 * Implements the {@code IConversionStrategy} interface to perform the conversion from   Kilometers(Km) to Meters(m) using the formula.
 * </p>
 * <pre>
 * Meter = kilometer * 1000
 * </pre>
 * 
 * <p>
 * The result printed to the console with two decimal places for Kilometers
 * and three decimal places for Meters.
 * </p>
 * @author Purnima
 * 
 */
public class KilometerToMeter  implements IConversionStrategy  {
     /**
    * converts the given distance in  Kilometers to Meters and prints the result.
    * @param kilometer  the distance value in kilometers.
    */ 
    @Override
    public void convert(double kilometer) {
       // throw new UnsupportedOperationException("Not supported yet."); //
       double meter = kilometer * 1000;
       System.out.printf("From %.2f km to %.3f m%n",kilometer, meter);
    }
}